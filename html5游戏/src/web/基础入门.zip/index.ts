//引入phaser的Game和场景
import {AUTO, Game,Scene} from "phaser";

class Demo extends Scene{
    constructor(){
        super("demo");
    }

    //加载资源
    public preload(){
        this.load.setBaseURL("http://labs.phasr.io"); //设立基础的url
        this.load.image("sky","assets/skies/space3.png"); //加载sky图片，放入到assets、skies、space下
        this.load.image("red","assets/sprites/phaser3-logo.png"); //加载sky图片，放入到assets、skies、space下
        this.load.image("logo","assets/particles/red.png"); //加载sky图片，放入到assets、skies、space下
    }

    public create(){
       // this.add.image(400,300,"sky"); //将sky这个图片加载到400,300的位置
        //利用物理引擎创建例子引擎
        //创建粒子发射器
        const particles = this.add.particles("red"); //将red图片作为创建发射器的母粒子
        const emitter = particles.createEmitter({ //可以参照粒子生成器
            speed:100, //速度
            scale:{  //缩放
                start:1,
                end:0
            },
            blendMode:"ADD" //平衡模式，性能相关
        });

        const logo = this.physics.add.image(400,100,'logo'); //给logo添加物理引擎
        logo.setVelocity(100,200);  //设置速度
        logo.setBounce(1,1);  //设置弹性系数
        logo.setCollideWorldBounds(true);  //设置碰撞检测

        //设置粒子特效根素物体
        emitter.startFollow(logo);
    }
}

const config:Phaser.Types.Core.GaemConfiig = {
    type:AUTO, //webGL,canvas 自动
    width:800,
    height:600,
    parent:'main', //页面中的元素
    physics:{ //定义物理引擎
        default:'arcade', //将个体都当做一个正方形
        arcade:{  //物理引擎的一些配置
            gravity:{ //重力加速度
                y:200
            }
        }
    },
    scene:Demo
};
const game =  new Game(config);